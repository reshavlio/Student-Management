package com.example.stedent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StedentApplicationTests {

	@Test
	void contextLoads() {
	}

}
