package com.example.stedent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StedentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StedentApplication.class, args);
	}

}
